<script setup>
import AppMenu from './AppMenu.vue';
</script>

<template>
    <app-menu></app-menu>
</template>

<style lang="scss" scoped></style>
