<script setup>

</script>

<template>
    <h1>About</h1>
    <p>A website for displaying the results of the UEFA Champions League (2023-2024) using <a href="https://vuejs.org/">VueJS</a> and <a href="https://primevue.org/">PrimeVue</a></p>
    <p>A tribute to <a href="https://www.football-data.org/">football-data.org</a> for providing the API in this project</p>
</template>
