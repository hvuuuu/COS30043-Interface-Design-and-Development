// Express server setup
const express = require('express');
const cors = require('cors');
const axios = require('axios');
const app = express();
const port = 5233; // Port number for the Express server

// Enable CORS for all routes
app.use(cors());

// Route to fetch standings
app.get('/api/standings', async (req, res) => {
    console.log("Fetching data from external API...");
    const apiUrl = 'https://api.football-data.org/v4/competitions/2001/standings'; // Replace with the actual URL
    try {
        const response = await axios.get(apiUrl, {
            headers: {
                'X-Auth-Token': '686e01d4cc1c48b5a67fd06f3c6700a3'
            }
        });
        const data = response.data;
        const groupAData = data.standings.find(group => group.group === 'Group A').table;
        const transformedData = groupAData.map(team => ({
            position: team.position,
            crest: team.team.crest,
            name: team.team.name,
            playedGames: team.playedGames,
            won: team.won,
            draw: team.draw,
            lost: team.lost,
            goalsFor: team.goalsFor,
            goalsAgainst: team.goalsAgainst,
            points: team.points
        }));
        res.json(transformedData);
    } catch (error) {
        console.error('Error fetching data:', error);
        res.status(500).send('Error fetching data');
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});