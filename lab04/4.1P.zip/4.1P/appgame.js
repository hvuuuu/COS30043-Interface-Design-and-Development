const app = Vue.createApp({
    data() {
        return {
            num_guess: '',
            num_target: Math.floor(Math.random() * 100) + 1,
            message: ''
        }
    },
    methods: {
        checkGuess() {
            if (this.num_guess < 1 || this.num_guess > 100 || this.num_guess === '') {
                this.message = 'Invalid guess';
            } else if (this.num_guess < this.num_target) {
                this.message = 'Guess higher';
            } else if (this.num_guess > this.num_target) {
                this.message = 'Guess lower';
            } else if (this.num_guess == this.num_target) {
                this.message = 'Correct guess!';
                
            }
        },
        giveUp() {
            this.message = 'The correct number was ' + this.num_target;
        },
        startOver() {
            this.num_guess = '';
            this.num_target = Math.floor(Math.random() * 100) + 1;
            this.message = '';
        }
    }
});

app.mount('#app')